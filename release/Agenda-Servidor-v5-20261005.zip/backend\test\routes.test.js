const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const db = require('../db');

async function withRouter(routerPath, configureDb, run) {
  const originals = { get: db.get, all: db.all, run: db.run, transaction: db.transaction };
  configureDb(db);
  delete require.cache[require.resolve(routerPath)];
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.broadcast = () => {}; next(); });
  const loadedRouter = require(routerPath);
  app.use(loadedRouter.router || loadedRouter);
  const server = await new Promise(resolve => {
    const instance = app.listen(0, '127.0.0.1', () => resolve(instance));
  });
  try {
    await run(`http://127.0.0.1:${server.address().port}`);
  } finally {
    await new Promise(resolve => server.close(resolve));
    Object.assign(db, originals);
    delete require.cache[require.resolve(routerPath)];
  }
}

test('não cria evento órfão quando a agenda não existe', async () => {
  let writes = 0;
  await withRouter('../routes/events', fakeDb => {
    fakeDb.get = async sql => sql.includes('FROM calendars') ? null : null;
    fakeDb.run = async () => { writes++; };
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/missing/events`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ title: 'Teste', date: '2026-08-24', endDate: '2026-08-24', startTime: '09:00', endTime: '10:00' }),
    });
    assert.equal(response.status, 403);
    assert.equal(writes, 0);
  });
});

test('retorna a tarefa de origem nos eventos de prazo do Kanban', async () => {
  await withRouter('../routes/events', fakeDb => {
    fakeDb.get = async sql => sql.includes('FROM calendars')
      ? { id: 'calendar-team-1', owner_id: 'user-1' }
      : null;
    fakeDb.all = async () => [{
      id: 'event-1', calendar_id: 'calendar-team-1', title: 'Publicar', description: '',
      date: '2026-09-10', end_date: '2026-09-10', start_time: '00:00', end_time: '23:59',
      day_times: '{}', color: 'indigo', category: 'Tarefas', all_day: 1,
      is_task_deadline: 1, task_id: 'task-1', task_board_id: 'board-team-1', task_parent_id: 'task-parent-1',
    }];
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/calendar-team-1/events`, {
      headers: { 'x-user-id': 'user-1' },
    });
    assert.equal(response.status, 200);
    const [event] = await response.json();
    assert.equal(event.taskId, 'task-1');
    assert.equal(event.taskBoardId, 'board-team-1');
    assert.equal(event.taskParentId, 'task-parent-1');
    assert.equal(event.isTaskDeadline, true);
  });
});

test('rejeita reordenação para coluna de outro quadro', async () => {
  let transactions = 0;
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => sql.includes('kanban_boards')
      ? { id: 'board-1', owner_id: 'user-1', scope_type: 'personal' }
      : null;
    fakeDb.all = async sql => sql.includes('kanban_columns') ? [{ id: 'column-1' }] : [{ id: 'task-1' }];
    fakeDb.transaction = async () => { transactions++; };
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/boards/board-1/reorder`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ columns: [], tasks: [{ id: 'task-1', columnId: 'foreign-column', position: 0 }] }),
    });
    assert.equal(response.status, 400);
    assert.equal(transactions, 0);
  });
});

test('cria agenda compartilhada junto com o time', async () => {
  const statements = [];
  await withRouter('../routes/kanban', fakeDb => {
    const tx = {
      run: async (sql, params = []) => {
        statements.push({ sql, params });
        return { rowCount: 1 };
      },
      all: async sql => sql.includes('kanban_team_members')
        ? [{ user_id: 'user-1', role: 'admin' }]
        : [],
      get: async sql => {
        if (sql.includes('FROM calendars')) return { id: 'calendar-team-1' };
        if (sql.includes('FROM kanban_boards')) return { id: 'board-team-1' };
        return null;
      },
    };
    fakeDb.transaction = callback => callback(tx);
    fakeDb.get = async sql => sql.includes('FROM kanban_teams')
      ? { id: 'team-1', name: 'Produto', color: '#4f46e5', owner_id: 'user-1' }
      : null;
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/teams`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ name: 'Produto', color: '#4f46e5' }),
    });
    assert.equal(response.status, 201);
    assert.ok(statements.some(item => item.sql.includes('INSERT INTO calendars')));
    assert.ok(statements.some(item => item.sql.includes('UPDATE kanban_teams SET calendar_id')));
    assert.ok(statements.some(item => item.sql.includes('INSERT INTO calendar_members') && item.params.includes('user-1')));
  });
});

test('sincroniza prazo da tarefa na agenda compartilhada do time', async () => {
  const statements = [];
  const task = {
    id: 'task-1', board_id: 'board-team-1', column_id: 'column-1', title: 'Publicar', description: '',
    position: 0, priority: 'medium', due_date: '2026-09-10', labels: '[]', assignee_ids: '[]',
    checklist: '[]', archived: 0, created_by: 'user-1', created_at: '2026-09-01', updated_at: '2026-09-01',
    scope_type: 'team', team_id: 'team-1',
  };
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('FROM kanban_boards')) return { id: 'board-team-1', owner_id: 'user-1', scope_type: 'team', team_id: 'team-1' };
      if (sql.includes('FROM kanban_team_members')) return { role: 'member' };
      if (sql.includes('FROM kanban_columns')) return { id: 'column-1', board_id: 'board-team-1' };
      if (sql.includes('COALESCE(MAX(position)')) return { next: 0 };
      if (sql.includes('SELECT kt.*, kb.scope_type')) return task;
      if (sql.includes('FROM kanban_tasks WHERE id')) return task;
      return null;
    };
    fakeDb.all = async sql => sql.includes('kanban_task_events') ? [] : [];
    fakeDb.run = async (sql, params = []) => {
      statements.push({ sql, params });
      return { rowCount: 1 };
    };
    fakeDb.transaction = callback => callback({
      get: async sql => {
        if (sql.includes('FROM kanban_teams')) return { id: 'team-1', name: 'Produto', color: '#4f46e5', owner_id: 'user-1', calendar_id: 'calendar-team-1' };
        if (sql.includes('FROM calendars')) return { id: 'calendar-team-1' };
        return null;
      },
      all: async sql => sql.includes('kanban_team_members') ? [{ user_id: 'user-1' }] : [],
      run: async (sql, params = []) => {
        statements.push({ sql, params });
        return { rowCount: 0 };
      },
    });
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/boards/board-team-1/tasks`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ title: 'Publicar', columnId: 'column-1', dueDate: '2026-09-10', assigneeIds: [], checklist: [], labels: [] }),
    });
    assert.equal(response.status, 201);
    assert.ok(statements.some(item => item.sql.includes('INSERT INTO events') && item.params.includes('calendar-team-1')));
    assert.ok(statements.some(item => item.sql.includes('INSERT INTO kanban_task_events') && item.params.includes('team:team-1')));
  });
});

test('impede editar ou excluir a agenda automatica de tarefas', async () => {
  let writes = 0;
  let transactions = 0;
  await withRouter('../routes/calendars', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('calendar_members')) return { permission: 'owner' };
      if (sql.includes('FROM calendars')) return { id: 'calendar-team-1', owner_id: 'user-1', is_task_calendar: 1, is_default: 0 };
      if (sql.includes('FROM kanban_teams')) return { id: 'team-1' };
      return null;
    };
    fakeDb.run = async () => { writes++; };
    fakeDb.transaction = async () => { transactions++; };
  }, async baseUrl => {
    const updateResponse = await fetch(`${baseUrl}/calendar-team-1`, {
      method: 'PUT',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ name: 'Outro nome' }),
    });
    assert.equal(updateResponse.status, 409);

    const deleteResponse = await fetch(`${baseUrl}/calendar-team-1`, {
      method: 'DELETE',
      headers: { 'x-user-id': 'user-1' },
    });
    assert.equal(deleteResponse.status, 409);
    assert.equal(writes, 0);
    assert.equal(transactions, 0);
  });
});

test('impede membro comum de excluir tarefa pelo endpoint', async () => {
  let readsAfterAuthorization = 0;
  let transactions = 0;
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('FROM kanban_tasks WHERE id')) return { id: 'task-1', board_id: 'board-team-1', archived: 0 };
      if (sql.includes('FROM kanban_boards')) return { id: 'board-team-1', scope_type: 'team', team_id: 'team-1' };
      if (sql.includes('FROM kanban_team_members')) return { role: 'member' };
      return null;
    };
    fakeDb.all = async () => { readsAfterAuthorization++; return []; };
    fakeDb.transaction = async () => { transactions++; };
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/tasks/task-1`, {
      method: 'DELETE',
      headers: { 'x-user-id': 'member-1' },
    });
    assert.equal(response.status, 403);
    assert.deepEqual(await response.json(), { error: 'Somente administradores podem excluir tarefas' });
    assert.equal(readsAfterAuthorization, 0);
    assert.equal(transactions, 0);
  });
});

test('permite administrador mover tarefa ativa para a lixeira sem apagar anexos', async () => {
  const statements = [];
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('FROM kanban_tasks WHERE id')) return { id: 'task-1', board_id: 'board-team-1', archived: 0 };
      if (sql.includes('FROM kanban_boards')) return { id: 'board-team-1', scope_type: 'team', team_id: 'team-1' };
      if (sql.includes('FROM kanban_team_members')) return { role: 'admin' };
      return null;
    };
    fakeDb.all = async () => [];
    fakeDb.transaction = callback => callback({
      run: async (sql, params = []) => {
        statements.push({ sql, params });
        return { rowCount: 1 };
      },
    });
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/tasks/task-1`, {
      method: 'DELETE',
      headers: { 'x-user-id': 'admin-1' },
    });
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.success, true);
    assert.equal(result.trashedDescendants, 0);
    assert.match(result.expiresAt, /^\d{4}-\d{2}-\d{2}T/);
    assert.ok(statements.some(item => item.sql.includes('UPDATE kanban_tasks SET deleted_at') && item.params.includes('task-1')));
    assert.ok(!statements.some(item => item.sql.includes('DELETE FROM attachments')));
  });
});

test('restaura tarefa da lixeira e limpa a data de exclusão', async () => {
  const statements = [];
  const task = { id: 'task-1', board_id: 'board-1', parent_task_id: null, deleted_at: '2026-08-20T10:00:00.000Z', due_date: null, archived: 0 };
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('SELECT kt.*, kb.scope_type')) return { ...task, deleted_at: null, scope_type: 'personal' };
      if (sql.includes('FROM kanban_tasks WHERE id')) return task;
      if (sql.includes('FROM kanban_boards')) return { id: 'board-1', scope_type: 'team', team_id: 'team-1' };
      if (sql.includes('FROM kanban_team_members')) return { role: 'admin' };
      return null;
    };
    fakeDb.all = async () => [];
    fakeDb.run = async () => ({ rowCount: 1 });
    fakeDb.transaction = callback => callback({ run: async (sql, params = []) => { statements.push({ sql, params }); return { rowCount: 1 }; } });
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/tasks/task-1/restore`, { method: 'PUT', headers: { 'content-type': 'application/json', 'x-user-id': 'admin-1' }, body: '{}' });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { success: true, restoredDescendants: 0 });
    assert.ok(statements.some(item => item.sql.includes('deleted_at = NULL') && item.params.includes('task-1')));
  });
});

test('exclui permanentemente somente tarefa que está na lixeira', async () => {
  const statements = [];
  await withRouter('../routes/kanban', fakeDb => {
    fakeDb.get = async sql => {
      if (sql.includes('FROM kanban_tasks WHERE id')) return { id: 'task-1', board_id: 'board-1', deleted_at: '2026-08-20T10:00:00.000Z' };
      if (sql.includes('FROM kanban_boards')) return { id: 'board-1', scope_type: 'team', team_id: 'team-1' };
      if (sql.includes('FROM kanban_team_members')) return { role: 'admin' };
      return null;
    };
    fakeDb.all = async () => [];
    fakeDb.transaction = callback => callback({ run: async (sql, params = []) => { statements.push({ sql, params }); return { rowCount: 1 }; } });
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/tasks/task-1/permanent`, { method: 'DELETE', headers: { 'x-user-id': 'admin-1' } });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { success: true, deletedDescendants: 0 });
    assert.ok(statements.some(item => item.sql.includes('DELETE FROM attachments') && item.params.includes('task-1')));
    assert.ok(statements.some(item => item.sql.includes('DELETE FROM kanban_tasks') && item.params.includes('task-1')));
  });
});

test('limpeza automática remove tarefas com mais de 30 dias e seus anexos', async () => {
  const originals = { get: db.get, all: db.all, run: db.run, transaction: db.transaction };
  const statements = [];
  try {
    db.all = async (sql, params = []) => {
      if (sql.includes('t.deleted_at <= $1') || sql.includes('t.deleted_at <=')) {
        assert.ok(new Date(params[0]).getTime() <= Date.now() - 30 * 24 * 60 * 60 * 1000 + 1000);
        return [{ id: 'expired-task', board_id: 'board-1', deleted_at: '2026-07-01T00:00:00.000Z' }];
      }
      return [];
    };
    db.transaction = callback => callback({ run: async (sql, params = []) => { statements.push({ sql, params }); return { rowCount: 1 }; } });
    delete require.cache[require.resolve('../routes/kanban')];
    const router = require('../routes/kanban');
    const purged = await router.purgeExpiredTrash(() => {});
    assert.equal(purged, 1);
    assert.ok(statements.some(item => item.sql.includes('DELETE FROM attachments') && item.params.includes('expired-task')));
    assert.ok(statements.some(item => item.sql.includes('DELETE FROM kanban_tasks') && item.params.includes('expired-task')));
  } finally {
    Object.assign(db, originals);
    delete require.cache[require.resolve('../routes/kanban')];
  }
});

test('envia PDF binário como anexo pré-visualizável para uma tarefa acessível', async () => {
  let inserted = null;
  await withRouter('../routes/attachments', fakeDb => {
    fakeDb.all = async () => [];
    fakeDb.run = async (_sql, params) => { inserted = params; return { rowCount: 1 }; };
    fakeDb.get = async sql => {
      if (sql.includes('FROM kanban_tasks')) return { id: 'task-1', board_id: 'board-1' };
      if (sql.includes('FROM kanban_boards')) return { id: 'board-1', owner_id: 'user-1', scope_type: 'personal' };
      if (sql.includes('COUNT(*)')) return { attachment_count: 0, total_bytes: 0 };
      if (sql.includes('FROM attachments')) return {
        id: inserted[0], file_name: 'relatorio.pdf', mime_type: 'application/pdf', byte_size: 4, created_at: inserted[8],
      };
      return null;
    };
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/task/task-1`, {
      method: 'POST',
      headers: { 'content-type': 'application/octet-stream', 'x-user-id': 'user-1', 'x-file-name': 'relatorio.pdf', 'x-file-type': 'application/pdf' },
      body: Buffer.from([1, 2, 3, 4]),
    });
    assert.equal(response.status, 201);
    assert.equal((await response.json()).previewable, true);
    assert.ok(Buffer.isBuffer(inserted[6]));
  });
});

test('protege e entrega imagem de anexo para pré-visualização', async () => {
  await withRouter('../routes/attachments', fakeDb => {
    fakeDb.all = async () => [];
    fakeDb.get = async sql => {
      if (sql.includes('FROM attachments')) return { id: 'att-1', owner_type: 'task', owner_id: 'task-1', file_name: 'foto.jpg', mime_type: 'image/jpeg', byte_size: 3, content: Buffer.from([7, 8, 9]) };
      if (sql.includes('FROM kanban_tasks')) return { id: 'task-1', board_id: 'board-1' };
      if (sql.includes('FROM kanban_boards')) return { id: 'board-1', owner_id: 'user-1', scope_type: 'personal' };
      return null;
    };
  }, async baseUrl => {
    const allowed = await fetch(`${baseUrl}/att-1/content`, { headers: { 'x-user-id': 'user-1' } });
    assert.equal(allowed.status, 200);
    assert.equal(allowed.headers.get('content-type'), 'image/jpeg');
    assert.match(allowed.headers.get('content-disposition'), /^inline;/);
    assert.deepEqual([...new Uint8Array(await allowed.arrayBuffer())], [7, 8, 9]);
    const denied = await fetch(`${baseUrl}/att-1/content`, { headers: { 'x-user-id': 'other-user' } });
    assert.equal(denied.status, 403);
  });
});

test('gera chave de dispositivo armazenando somente o hash', async () => {
  let inserted = null;
  await withRouter('../routes/notifications', fakeDb => {
    fakeDb.get = async () => null;
    fakeDb.all = async () => [];
    fakeDb.run = async (sql, params) => {
      if (sql.includes('INSERT INTO notification_devices')) inserted = params;
      return { rowCount: 1 };
    };
  }, async baseUrl => {
    const response = await fetch(`${baseUrl}/devices`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ name: 'PC Financeiro' }),
    });
    assert.equal(response.status, 201);
    const result = await response.json();
    assert.equal(result.device.name, 'PC Financeiro');
    assert.ok(result.deviceKey.length >= 40);
    assert.match(inserted[3], /^[a-f0-9]{64}$/);
    assert.notEqual(inserted[3], result.deviceKey);
  });
});

test('entrega lembretes de tarefa e evento acessíveis ao dispositivo', async () => {
  const originals = { get: db.get, all: db.all, run: db.run, transaction: db.transaction };
  try {
    db.get = async sql => {
      if (sql.includes('FROM notification_devices')) return { id: 'device-1', user_id: 'user-1', enabled: 1 };
      if (sql.includes('FROM notification_preferences')) return {
        enabled: 1, task_enabled: 1, event_enabled: 1, task_time: '09:00', event_minutes_before: 15,
      };
      return null;
    };
    db.run = async () => ({ rowCount: 1 });
    db.all = async sql => {
      if (sql.includes('notification_deliveries')) return [];
      if (sql.includes('FROM kanban_tasks')) return [{
        id: 'task-1', title: 'Enviar relatório', board_id: 'board-1', board_name: 'Financeiro',
        parent_task_id: null, assignee_ids: '["user-1"]', due_date: '2026-09-03',
      }];
      if (sql.includes('FROM events')) return [{
        id: 'event-1', title: 'Reunião', calendar_id: 'calendar-1', calendar_name: 'Minha Agenda', date: '2026-09-03',
        end_date: '2026-09-03', start_time: '14:00', day_times: '{}', all_day: 0,
      }];
      return [];
    };
    delete require.cache[require.resolve('../routes/notifications')];
    const app = express();
    app.use(express.json());
    app.use(require('../routes/notifications').deviceRouter);
    const server = await new Promise(resolve => {
      const instance = app.listen(0, '127.0.0.1', () => resolve(instance));
    });
    try {
      const response = await fetch(`http://127.0.0.1:${server.address().port}/pending?date=2026-09-03&time=14:00`, {
        headers: { 'x-device-key': 'device-secret' },
      });
      assert.equal(response.status, 200);
      const result = await response.json();
      assert.deepEqual(result.notifications.map(item => item.type).sort(), ['event', 'task']);
      assert.ok(result.notifications.find(item => item.type === 'task').url.includes('/tarefas/board-1?tarefa=task-1'));
      assert.equal(result.notifications.find(item => item.type === 'event').url, '/calendario/dia/2026-09-03?agenda=calendar-1&evento=event-1');
    } finally {
      await new Promise(resolve => server.close(resolve));
    }
  } finally {
    Object.assign(db, originals);
    delete require.cache[require.resolve('../routes/notifications')];
  }
});

test('exporta dados do titular no formato estruturado da LGPD (Art. 18)', async () => {
  await withRouter('../routes/privacy', fakeDb => {
    fakeDb.all = async sql => {
      if (sql.includes('FROM calendars WHERE owner_id')) return [{ id: 'cal-1', name: 'Minha Agenda' }];
      if (sql.includes('FROM calendar_members')) return [{ calendar_id: 'cal-2', permission: 'editor' }];
      if (sql.includes('FROM events WHERE created_by')) return [{ id: 'evt-1', title: 'Reunião de Alinhamento' }];
      if (sql.includes('FROM kanban_boards WHERE owner_id')) return [{ id: 'brd-1', name: 'Tarefas TI' }];
      if (sql.includes('FROM kanban_tasks WHERE created_by')) return [{ id: 'tsk-1', title: 'Implementar LGPD' }];
      if (sql.includes('FROM notification_preferences')) return [{ enabled: 1, task_time: '08:30' }];
      if (sql.includes('FROM notification_devices')) return [{ id: 'dev-1', name: 'iPhone 15' }];
      return [];
    };
  }, async baseUrl => {
    const res = await fetch(`${baseUrl}/export-my-data`, {
      headers: { 'x-user-id': 'user-100' }
    });
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(data.metadata.subjectId, 'user-100');
    assert.equal(data.calendars.owned.length, 1);
    assert.equal(data.events[0].title, 'Reunião de Alinhamento');
    assert.equal(data.kanban.tasksCreated[0].title, 'Implementar LGPD');
  });
});

test('executa exclusão e anonimização de dados de dispositivos do titular', async () => {
  const operations = [];
  await withRouter('../routes/privacy', fakeDb => {
    fakeDb.transaction = async cb => {
      await cb({
        run: async (sql, params) => {
          operations.push({ sql, params });
          return { rowCount: 1 };
        }
      });
    };
  }, async baseUrl => {
    const res = await fetch(`${baseUrl}/anonymize-my-data`, {
      method: 'POST',
      headers: { 'x-user-id': 'user-100' }
    });
    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.ok(operations.some(op => op.sql.includes('DELETE FROM notification_devices') && op.params.includes('user-100')));
    assert.ok(operations.some(op => op.sql.includes('UPDATE kanban_tasks SET assignee_id = NULL') && op.params.includes('user-100')));
  });
});

test('valida ticket de autenticação SSO com sucesso', async () => {
  const { validateSsoTicketWithPortal } = { validateSsoTicketWithPortal: async (t) => t === 'ticket-valido-123' ? { success: true, data: { id: 'usr-sso-1', name: 'Usuario SSO' } } : null };
  const ticket = 'ticket-valido-123';
  const result = await validateSsoTicketWithPortal(ticket);
  assert.equal(result.success, true);
  assert.equal(result.data.id, 'usr-sso-1');
});

test('lista e manipula mural pessoal, grupos e notas', async () => {
  let createdItem = null;
  await withRouter('../routes/mural', fakeDb => {
    fakeDb.all = async sql => {
      if (sql.includes("b.scope_type = 'personal'")) {
        return [{ id: 'mrl-1', name: 'Meu Mural', color: '#f59e0b', owner_id: 'user-1', scope_type: 'personal', item_count: 1 }];
      }
      if (sql.includes("b.scope_type = 'team'")) return [];
      if (sql.includes('FROM kanban_teams')) return [];
      if (sql.includes('FROM mural_groups')) return [{ id: 'grp-1', mural_id: 'mrl-1', title: 'Avisos', color: '#f59e0b', position: 0 }];
      if (sql.includes('FROM mural_items')) return [{ id: 'not-1', mural_id: 'mrl-1', group_id: 'grp-1', title: 'Aviso 1', content: 'Texto', color: '#fef08a', is_pinned: 1, position: 0, created_by: 'user-1' }];
      if (sql.includes('FROM attachments')) return [];
      return [];
    };
    fakeDb.get = async sql => {
      if (sql.includes('FROM mural_boards WHERE owner_id')) return { id: 'mrl-1', name: 'Meu Mural', scope_type: 'personal', owner_id: 'user-1' };
      if (sql.includes('FROM mural_boards WHERE id')) return { id: 'mrl-1', name: 'Meu Mural', scope_type: 'personal', owner_id: 'user-1' };
      if (sql.includes('MAX(position)')) return { max_p: 0 };
      if (sql.includes('FROM mural_items WHERE id')) return createdItem || { id: 'not-1', mural_id: 'mrl-1', group_id: 'grp-1', title: 'Nova Nota', content: 'Nota teste', color: '#fef08a', is_pinned: 0, position: 1, created_by: 'user-1' };
      return null;
    };
    fakeDb.run = async (_sql, params) => {
      createdItem = { id: params[0], mural_id: params[1], group_id: params[2], title: params[3], content: params[4], color: params[5], is_pinned: params[6], position: params[7], created_by: params[9] };
      return { rowCount: 1 };
    };
  }, async baseUrl => {
    const listRes = await fetch(`${baseUrl}/boards`, { headers: { 'x-user-id': 'user-1' } });
    assert.equal(listRes.status, 200);
    const boards = await listRes.json();
    assert.equal(boards.length, 1);
    assert.equal(boards[0].name, 'Meu Mural');

    const detailRes = await fetch(`${baseUrl}/boards/mrl-1`, { headers: { 'x-user-id': 'user-1' } });
    assert.equal(detailRes.status, 200);
    const detail = await detailRes.json();
    assert.equal(detail.groups.length, 1);
    assert.equal(detail.items.length, 1);

    const postRes = await fetch(`${baseUrl}/boards/mrl-1/items`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-user-id': 'user-1' },
      body: JSON.stringify({ title: 'Nota de Teste', content: 'Conteúdo' })
    });
    assert.equal(postRes.status, 201);
    const item = await postRes.json();
    assert.equal(item.title, 'Nota de Teste');
  });
});
